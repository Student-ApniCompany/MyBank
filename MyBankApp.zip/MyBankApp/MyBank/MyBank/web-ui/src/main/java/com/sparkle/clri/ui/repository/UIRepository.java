package com.sparkle.clri.ui.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.sparkle.clri.ui.session.model.SessionData;



@Repository
public interface UIRepository extends JpaRepository<SessionData, String> {
	
	SessionData findByAccountNo(String accountId);

}