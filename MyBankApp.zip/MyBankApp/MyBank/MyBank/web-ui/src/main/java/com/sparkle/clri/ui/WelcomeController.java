package com.sparkle.clri.ui;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URI;
import java.text.NumberFormat;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.sparkle.clri.ui.model.Login;
import com.sparkle.clri.ui.repository.LoginRepository;
import com.sparkle.clri.ui.service.UIServiceImpl;
import com.sparkle.clri.ui.session.model.SessionData;

import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.HttpTextFormat;
import io.opentelemetry.trace.Span;
import io.opentelemetry.trace.SpanContext;
import io.opentelemetry.trace.Tracer;

@Controller
public class WelcomeController {

	@Autowired
	private Environment env;

	@Autowired
	private UIServiceImpl uiService;
	
	@Autowired
	Tracer tracer;

	@Autowired
	private LoginRepository loginRepository;
	
	@RequestMapping("/")
	public String welcome(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value="/logout", method = RequestMethod.POST)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response, Model model) {
		model.addAttribute("login", new Login());
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("message", "You have successfully loggged out !!");;
		return mav;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") Login login, RedirectAttributes redirectAttributes) {
		ModelAndView mav = null;

		String location=getGeoLocation(request.getRemoteHost());
		Span span = tracer.spanBuilder("/login").startSpan();
		span.addEvent("Xrae UI login page");
		span.setAttribute("request.type", "login page");
		span.setAttribute("http.method", "POST");
		if(location!=null)
			span.setAttribute("geo.location", location);
		
		if ((login.getUsername() == null || login.getUsername().isEmpty())
				&& (login.getPassword() == null || login.getPassword().isEmpty())) {
			mav = new ModelAndView("login");
			span.addEvent("Username and Password missing");
            span.setAttribute("error", true);
            span.setAttribute("http.status_code", "500");
			mav.addObject("message", "Please supply Username and Password!!");

		} else if (login.getUsername() == null || login.getUsername().isEmpty()) {
			mav = new ModelAndView("login");
			span.addEvent("Username missing");
            span.setAttribute("error", true);
            span.setAttribute("http.status_code", "500");
			mav.addObject("message", "Username cannot be empty!!");

		} else if (login.getPassword() == null || login.getPassword().isEmpty()) {
			mav = new ModelAndView("login");
			span.addEvent("Password missing");
            span.setAttribute("error", true);
            span.setAttribute("http.status_code", "500");
			
			mav.addObject("message", "Password cannot be empty!!");

		} else {
			String userName = login.getUsername();
			String password = login.getPassword();
			
			try(Scope scope = tracer.withSpan(span)){
				span.setAttribute("userId", userName);
				validateUser(userName, password);
			}catch(HttpClientErrorException e){
				if(e.getRawStatusCode()==401 || e.getRawStatusCode()==400){
					mav = new ModelAndView("login");
					mav.addObject("message", "Invalid credentials. Please try again!!");
					span.addEvent("Invalid Credentials");
		            span.setAttribute("error", true);
		            span.setAttribute("http.status_code", "500");
		            span.end();
					return mav;
				}
			
			}catch(Exception e){
					span.addEvent("Something went wrong...");
		            span.setAttribute("error", true);
		            span.setAttribute("http.status_code", "500");
		            span.end();
					mav = new ModelAndView("login");
					mav.addObject("message", "Something went wrong... Please try again!!");
					return mav;
			}
			
			try(Scope scope = tracer.withSpan(span)){
			int balance = getBalance(userName);
			NumberFormat formatter = NumberFormat.getCurrencyInstance();

			SessionData data = new SessionData();
			data.setAccountNo(userName);
			data.setBalance(balance);
			uiService.createaccount(data);
			
/*			HttpSession session = request.getSession();
			session.setAttribute("token", token);
			session.setAttribute("user", userName);
			session.setAttribute("balance1", formatter.format(balance));
			session.setAttribute("balance2", formatter.format(balance));*/
			
			mav = new ModelAndView(new RedirectView("/home", true));
			redirectAttributes.addFlashAttribute("balance", formatter.format(balance));
			redirectAttributes.addFlashAttribute("username", login.getUsername());
			HttpSession session = request.getSession();
			session.setAttribute("username", userName);
			span.end();
			return mav;
			}
		}
		span.end();
		return mav;

	}

	
	  @RequestMapping(value = "/home" ,method = RequestMethod.GET)
	  public ModelAndView test(HttpServletRequest request, HttpServletResponse response, Model model) {
	      ModelAndView mav = new ModelAndView("home");
	      mav.addObject("username", model.asMap().get("username"));
		  mav.addObject("balance1", model.asMap().get("balance"));
		  mav.addObject("balance2", model.asMap().get("balance"));
	      return mav;
	  }
	  
	  
		
	  @RequestMapping(value = "/balance" ,method = RequestMethod.POST)
	  public @ResponseBody String balance(HttpServletRequest request, HttpServletResponse response) {
		  
		  HttpSession session = request.getSession(false);
		  String user = (String) session.getAttribute("username");
		  SessionData sessionData= uiService.fetchAccount(user);
		  int balance = sessionData.getBalance();
		  NumberFormat formatter = NumberFormat.getCurrencyInstance();
	      return formatter.format(balance);
	  }
	  
	
	@RequestMapping(value = "/cheque", method = RequestMethod.POST)
	public @ResponseBody String loginProcess(HttpServletRequest request, HttpServletResponse response) {
		
		 Span span = tracer.spanBuilder("/cheque").startSpan();
		 span.setAttribute("request.type", "create cheque request");
		
		 HttpSession session = request.getSession(false);
         String user = (String) session.getAttribute("username");
		  
		JSONObject data = new JSONObject();
        try{
			data.put("chequeBookCount", request.getHeader("chequeBookCount"));
			data.put("leafsPerBook", request.getHeader("leafsPerBook"));
			data.put("address", request.getHeader("address"));
			data.put("accountNo", user);
			data.put("userId", user);
		}catch(JSONException e){
			//null
		}
        try(Scope scope = tracer.withSpan(span)){
        String requestNo= createChequeRequest(user, data);
        return requestNo;
        }finally {
			span.end();
		}
        
	}

	private void validateUser(String user, String password) throws IllegalArgumentException {
			
			Span span = tracer.spanBuilder("validateUser").startSpan();
			span.setAttribute("peer.service", "mysql");
			span.setAttribute("request.type", "SQL QUERY");
			span.setAttribute("sql.query", "SELECT * FROM login WHERE username="+user);
			
			Login logindata=loginRepository.findByUsername(user);
			
			if( logindata == null || !logindata.getPassword().equalsIgnoreCase(password)){
				span.addEvent("No login details exists");
	            span.setAttribute("error", true);
	            span.setAttribute("http.status_code", "500");
				span.end();
				throw new IllegalArgumentException("Invalid credentials. Please try again!!");
			}
			span.end();
			
		}

	private Integer getBalance(String user) {
		Span span = tracer.spanBuilder("getBalance").startSpan();
		span.setAttribute("request.type", "get account balance");
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
		HttpTextFormat<SpanContext> textFormat = tracer.getHttpTextFormat();
		textFormat.inject(span.getContext(), header, new
			      HttpTextFormat.Setter<HttpHeaders>(){

					@Override
					public void put(HttpHeaders template, String key, String value) {
						header.add(key, value);
						
					}
			
		});
		
		String endpoint = env.getProperty("account.balance.endpoint");
		header.set("username", user);
		/*SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("orrproxy.mphasis.com", 8080));
		clientHttpReq.setProxy(proxy);
				 
		RestTemplate restTemplate = new RestTemplate(clientHttpReq);*/
		
		URI uri = URI.create(endpoint + user);
		ResponseEntity response = restTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<>(header), Integer.class);
		Integer balance = (Integer) response.getBody();
		span.end();
		return balance;

	}

	private String createChequeRequest(String user, JSONObject body) {
		Span span = tracer.spanBuilder("createChequeRequest").startSpan();
		span.setAttribute("request.type", "cheque request creation");
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		HttpTextFormat<SpanContext> textFormat = tracer.getHttpTextFormat();
		textFormat.inject(span.getContext(), headers, new
			      HttpTextFormat.Setter<HttpHeaders>(){

					@Override
					public void put(HttpHeaders template, String key, String value) {
						headers.add(key, value);
						
					}
			
		});
		
		String endpoint = env.getProperty("cheque.request.endpoint");
		headers.set("username", user);
		headers.setContentType(MediaType.APPLICATION_JSON);
		/*SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("orrproxy.mphasis.com", 8080));
		clientHttpReq.setProxy(proxy);
				 
		RestTemplate restTemplate = new RestTemplate(clientHttpReq);*/
		
		
		URI uri = URI.create(endpoint);
		HttpEntity<?> entity = new HttpEntity<Object>(body.toString(), headers);
		ResponseEntity response = restTemplate.exchange(uri, HttpMethod.POST, entity, String.class);
		String requestId = (String) response.getBody();
		span.end();
		return requestId;

	}

	
	public String getGeoLocation(String ipaddress) {
		try{
		File database = new File("/var/lib/geo/GeoLite2-City.mmdb");
		DatabaseReader dbReader = new DatabaseReader.Builder(database).build();
		if (ipaddress.equals("0:0:0:0:0:0:0:1"))
			ipaddress = "127.0.0.1";
		
		InetAddress ipAddress = InetAddress.getByName(ipaddress);
		
		CityResponse response = dbReader.city(ipAddress);
		
		String countryName = response.getCountry().getName();
		String cityName = response.getCity().getName();
		Double latitude = response.getLocation().getLatitude();
		Double longitude = response.getLocation().getLongitude();
		return cityName+":"+countryName+":"+latitude+":"+longitude;
		}catch(IOException | GeoIp2Exception ex ){
			System.out.println(ex.getMessage());
			return null;
	 }
		
		 
	}

}