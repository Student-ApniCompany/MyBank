package com.sparkle.clri.ui.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sparkle.clri.ui.repository.UIRepository;
import com.sparkle.clri.ui.session.model.SessionData;

@Service
public class UIServiceImpl {

	Logger logger = LoggerFactory.getLogger(UIServiceImpl.class);
	@Autowired
	private UIRepository uiRepository;

	public SessionData fetchAccount(String id) {
		SessionData sessionData = uiRepository.findByAccountNo(id);

		return sessionData;
	}

	public void createaccount(SessionData data) {

		SessionData sessionData = uiRepository.findByAccountNo(data.getAccountNo());
		if (sessionData != null) {
			uiRepository.delete(sessionData);
		}
		SessionData session = new SessionData();
		session.setAccountNo(data.getAccountNo());
		session.setBalance(data.getBalance());

		uiRepository.save(session);
	}

}
