package com.sparkle.clri.ui.session.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="sessiondata")
public class SessionData {
	
	@Id
	@Column(name = "account_no", nullable = false, updatable = false)
	private String accountNo;
	@Column(name="balance")
	private Integer balance;
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public Integer getBalance() {
		return balance;
	}
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	
	
	
	
}
