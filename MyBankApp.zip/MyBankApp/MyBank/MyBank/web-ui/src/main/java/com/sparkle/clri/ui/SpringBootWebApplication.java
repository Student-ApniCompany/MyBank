package com.sparkle.clri.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication(scanBasePackages = { "com.sparkle.clri.ui", "com.sparkle.clri.ui.model",
		"com.sparkle.clri.service", "com.sparkle.clri.ui.session.model", "com.sparkle.clri.ui.repository", "com.sparkle.clri.ui.tracer", "com.sparkle.clri.ui.configuration"})
@EnableJpaRepositories("com.sparkle.clri.ui.repository")
@EntityScan(basePackages= {"com.sparkle.clri.ui.model", "com.sparkle.clri.ui.session.model"})
public class SpringBootWebApplication{

	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootWebApplication.class, args);
	}

}