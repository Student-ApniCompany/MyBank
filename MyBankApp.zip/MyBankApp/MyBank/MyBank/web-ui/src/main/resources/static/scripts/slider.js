$(function() {
			//Store frequently elements in variables
			var slider  = $('#slider'),
				tooltip = $('.tooltip');
			//Hide the Tooltip at first
			//tooltip.hide();
			//Call the Slider
			slider.slider({
				//Config
				range: "min",
				min: 0,
				max:500,
				value: 100,
				start: function(event,ui) {
				    tooltip.fadeIn('fast');
				},

				//Slider Event
				slide: function(event, ui) { //When the slider is sliding				
				
					var value  = slider.slider('value'),
						volume = $('.volume');		
					value=value/5;					
					var l = $(".ui-slider-handle").css("left");					
					l = l.substring(0, l.length - 2)
					l = (l-25)+"px";
					tooltip.css('left',l).text(ui.value);  //Adjust the tooltip accordingly					
					if(value <= 25) { 
						volume.css('background-position', '0 0');
					} 
					else if (value <= 125) {
						volume.css('background-position', '0 -25px');
					} 
					else if (value <= 300) {
						volume.css('background-position', '0 -50px');
					} 
					else {
						volume.css('background-position', '0 -75px');
					};

				},
				stop: function(event,ui) {
				    //tooltip.fadeOut('fast');
				},
			});
			
		});