SET SQL_MODE='ALLOW_INVALID_DATES'; 


CREATE TABLE if not exists sessiondata (
    account_no VARCHAR(255) PRIMARY KEY,
    token VARCHAR(255),
    balance integer	
);

