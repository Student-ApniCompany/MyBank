package com.sparkle.clri.cheque.service;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.sparkle.clri.cheque.model.Cheque;
import com.sparkle.clri.cheque.repository.ChequeRepository;
import com.sparkle.clri.cheque.vo.ChequeVO;
import com.sparkle.clri.exception.BusinessException;
import com.sparkle.clri.exception.Constants;

@Service
public class ChequeServiceImpl {

	Logger logger = LoggerFactory.getLogger(ChequeServiceImpl.class);

	@Value("${accounts.api.endpoint}")
	private String endpoint;

	@Autowired
	private ChequeRepository chequeRepository;

	
	public Object fetchRequestDetails(String requestNo) throws BusinessException
	{
		Cheque request= chequeRepository.findRequestDetails(requestNo);
		if (request == null) {
			logger.error("No records exists with the provided request number");
			throw new BusinessException(Constants.INVALID_REQUEST_NUMBER, "No records exists with the provided request number");
		}
		return request;
	}
	
	
	public Object fetchAllRequestDetails(String accountNo) throws BusinessException
	{
		List<Cheque> request= chequeRepository.findAccountRequestDetails(accountNo);
		if (request == null || request.size()==0) {
			logger.error("No records exists with the provided account number");
			throw new BusinessException(Constants.INVALID_REQUEST_NUMBER, "No records exists with the provided account number");
		}
		return request;
	}
	
	
	public Object fetchspecificChequeRequestDetails(String accountNo, String chequeNo) throws BusinessException
	{
		List<Cheque> request= chequeRepository.findAccountSpecificChequetDetails(accountNo, chequeNo);
		if (request == null || request.size()==0) {
			logger.error("No records exists with the provided account number and cheque request number");
			throw new BusinessException(Constants.INVALID_ACC_CHEQUE_REQUEST_NUMBER, "No records exists with the provided account number and cheque request number");
		}
		return request;
	}
	
	public Object fetchAllChequeRequestDetails() throws BusinessException
	{
		List<Cheque> request= chequeRepository.findAllRequestDetails();
		return request;
	}
	
	
	public String createChequeRequest(ChequeVO chequeVO) throws BusinessException{
		
		try{
		readAccountBalance(chequeVO.getAccountNo());
		}catch(ResourceAccessException e){
			throw new BusinessException(Constants.BAD_REQUEST, "");
		}catch(HttpClientErrorException e){
			throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, "");
		}
		
		int accountRequestNo = chequeRepository.findRequestId(chequeVO.getAccountNo());
		String requestNo = chequeVO.getAccountNo() + "_" + accountRequestNo;
		Cheque cheque = new Cheque();
		cheque.setAccountNo(chequeVO.getAccountNo());
		cheque.setUserId(chequeVO.getUserId());
		cheque.setAddress(chequeVO.getAddress());
		cheque.setLeafsPerBook(chequeVO.getLeafsPerBook());
		cheque.setChequeBookCount(chequeVO.getChequeBookCount());
		cheque.setRequestNo(requestNo);
		chequeRepository.save(cheque);
		return requestNo;
	}

	 
	public int readAccountBalance(String accountNo) {
		RestTemplate restTemplate = new RestTemplate();
		URI uri = URI.create(endpoint +"accountbalance/"+ accountNo);
		return restTemplate.getForObject(uri, Integer.class);
	}
	

}
