package com.sparkle.clri.cheque.vo;


public class ChequeVO {
	
	private String userId;
	private String accountNo;	
	private int chequeBookCount;	
	private int leafsPerBook;
	private String address;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public int getChequeBookCount() {
		return chequeBookCount;
	}
	public void setChequeBookCount(int chequeBookCount) {
		this.chequeBookCount = chequeBookCount;
	}
	public int getLeafsPerBook() {
		return leafsPerBook;
	}
	public void setLeafsPerBook(int leafsPerBook) {
		this.leafsPerBook = leafsPerBook;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
