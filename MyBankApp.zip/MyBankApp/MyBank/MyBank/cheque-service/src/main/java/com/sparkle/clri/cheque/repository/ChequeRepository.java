package com.sparkle.clri.cheque.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.sparkle.clri.cheque.model.Cheque;



@Repository
public interface ChequeRepository extends JpaRepository<Cheque, String> {
	
	@Query("select coalesce(count(account_no),0)+1 from cheques as a where a.accountNo=:id")
	int findRequestId(@Param("id") String id);
	
	@Query("FROM cheques as a where a.requestNo=:id")
	Cheque findRequestDetails(@Param("id") String id);
	
	@Query("FROM cheques as a where a.accountNo=:id")
	List<Cheque> findAccountRequestDetails(@Param("id") String id);
	
	@Query("FROM cheques as a where a.accountNo=:id and a.requestNo=:chequeid")
	List<Cheque> findAccountSpecificChequetDetails(@Param("id") String id, @Param("chequeid") String chequeid);
	
	
	@Query("FROM cheques")
	List<Cheque> findAllRequestDetails();

}