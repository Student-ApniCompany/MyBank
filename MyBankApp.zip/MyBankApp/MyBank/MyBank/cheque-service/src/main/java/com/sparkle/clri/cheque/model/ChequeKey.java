package com.sparkle.clri.cheque.model;

import java.io.Serializable;

public class ChequeKey implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String accountNo;
	private String requestNo;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getRequestNo() {
		return requestNo;
	}
	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}
	
	
	
}
