package com.sparkle.clri.cheque.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.sparkle.clri.cheque.service.ChequeServiceImpl;
import com.sparkle.clri.cheque.vo.ChequeVO;
import com.sparkle.clri.exception.BusinessException;



@RestController
public class ChequeController {

	
	private static final Logger logger = LoggerFactory.getLogger(ChequeController.class);
	
	@Autowired
	private ChequeServiceImpl chequeService;
	

	@RequestMapping(value = "/cheque", method = RequestMethod.POST)
	public String createChequeRequest(@RequestBody ChequeVO chequeVO) throws BusinessException
	{
		    String chequeReqId=chequeService.createChequeRequest(chequeVO);
			return chequeReqId;
	}
	
	@RequestMapping(value = "/cheque/requestid/{id}", method = RequestMethod.GET)
	public Object getRequestDetails(@PathVariable String id) throws BusinessException {
		logger.info("Get cheque request details");
		Object cheque = chequeService.fetchRequestDetails(id);
		return cheque;
	}
	
	@RequestMapping(value = "/cheque/account/{accountid}", method = RequestMethod.GET)
	public Object getAllRequestDetails(@PathVariable String accountid) throws BusinessException {
		logger.info("Get Account cheque request details");
			Object cheque = chequeService.fetchAllRequestDetails(accountid);
			return cheque;
	}
	
	@RequestMapping(value = "/cheque/{chequeid}/account/{accountid}", method = RequestMethod.GET)
	public Object getRequestDetails(@PathVariable String chequeid, @PathVariable String accountid) throws BusinessException {
		logger.info("Get Account specific cheque request details");
			Object cheque = chequeService.fetchspecificChequeRequestDetails(accountid, chequeid);
			return cheque;
	}
	
	
	@RequestMapping(value = "/cheques", method = RequestMethod.GET)
	public Object getAllChequeRequestDetails() throws BusinessException {
		logger.info("Get All cheque request details");
			Object cheque = chequeService.fetchAllChequeRequestDetails();
			return cheque;
	}
	
}
