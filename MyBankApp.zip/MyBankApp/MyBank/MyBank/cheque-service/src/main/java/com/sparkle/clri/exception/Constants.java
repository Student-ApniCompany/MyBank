package com.sparkle.clri.exception;

public final class Constants {
	public static final String SYSTEM_UNAVAILABLE = "system.error";
	public static final String ACC_BALANCE_ERR = "account.balance.error";
	public static final String INVALID_REQUEST_NUMBER = "invalid.request.number";
	public static final String BAD_REQUEST = "service.unavailable";
	public static final String ACCOUNT_NOT_FOUND = "account.notfound";
	public static final String INVALID_ACC_CHEQUE_REQUEST_NUMBER = "invalid.account.cheque.request.number";
}
