

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;



@SpringBootApplication(scanBasePackages = { "com.sparkle.clri.cheque.controller","com.sparkle.clri.cheque.model",
		"com.sparkle.clri.cheque.service","com.sparkle.clri.cheque.repository", "com.sparkle.clri.exception", "com.sparkle.clri.cheque.tracer", "com.sparkle.clri.cheque.configuration"})
@EnableJpaRepositories("com.sparkle.clri.cheque.repository")
@EntityScan("com.sparkle.clri.cheque.model")
@EnableAutoConfiguration
@RefreshScope
public class ClriChequeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClriChequeServiceApplication.class, args);
	}
}
