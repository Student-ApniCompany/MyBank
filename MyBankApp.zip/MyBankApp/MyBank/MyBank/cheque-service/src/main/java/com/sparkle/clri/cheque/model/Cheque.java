package com.sparkle.clri.cheque.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity(name="cheques")
@IdClass(ChequeKey.class)
public class Cheque {
	
	@Id
	@Column(name = "account_no", nullable = false, updatable = false)
	private String accountNo;
	@Column(name="user_id")
	private String userId;
	@Column(name="no_of_cheque_books")
	private Integer chequeBookCount;
	@Column(name="leafs_per_book")
	private Integer leafsPerBook;
	@Column(name="address")
	private String address;
	@Id
	@Column(name="request_no", nullable = false, updatable = false)
	private String requestNo;
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getChequeBookCount() {
		return chequeBookCount;
	}
	public void setChequeBookCount(Integer chequeBookCount) {
		this.chequeBookCount = chequeBookCount;
	}
	public Integer getLeafsPerBook() {
		return leafsPerBook;
	}
	public void setLeafsPerBook(Integer leafsPerBook) {
		this.leafsPerBook = leafsPerBook;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRequestNo() {
		return requestNo;
	}
	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}
	
	
}
