package com.sparkle.clri.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class BaseController{

	public static final Logger logger = LoggerFactory.getLogger(BaseController.class);


	@Autowired
	private Environment env;

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handle(BusinessException ex) {
		logger.error("error in business - " + ex.getErrorMessage());
		ErrorResponse response = new ErrorResponse();
		response.setErrorCode(ex.getErrorCode());
		response.setErrorMessage(env.getProperty(ex.getErrorCode()));
		return new ResponseEntity<ErrorResponse>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handle(Exception ex) {
		logger.error("error in system - " + ex);
		ErrorResponse response = new ErrorResponse();
		response.setErrorCode(Constants.SYSTEM_UNAVAILABLE);
		response.setErrorMessage(env.getProperty(Constants.SYSTEM_UNAVAILABLE));
		return new ResponseEntity<ErrorResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
