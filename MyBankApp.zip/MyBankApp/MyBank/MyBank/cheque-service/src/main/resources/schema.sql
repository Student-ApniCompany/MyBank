SET SQL_MODE='ALLOW_INVALID_DATES'; 


CREATE TABLE if not exists cheques (
    account_no VARCHAR(255),
	user_id VARCHAR(255),
    leafs_per_book integer,
    no_of_cheque_books integer,
	address VARCHAR(255),
	request_no VARCHAR(255),
	PRIMARY KEY (account_no, request_no)
);

