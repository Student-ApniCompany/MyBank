package com.sparkle.clri.exception;

public final class Constants {
	public static final String ACCOUNT_NOT_FOUND = "account.notfound";
	public static final String SYSTEM_UNAVAILABLE = "system.error";
	public static final String ACCOUNT_EXISTS = "account.exists";
}
