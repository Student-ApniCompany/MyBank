package com.sparkle.clri.accounts.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity(name="accounts")
public class Account {

	@Id
	@Column(name = "account_no", nullable = false, updatable = false)
	private String accountNo;
	@Column(name="name")
	private String accountName;
	@Column(name="balance")
	private Integer balance;
	@Column(name="type")
	private String accountType;

	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@Column(name="updatedOn")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedDate;

	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Integer getBalance() {
		return balance;
	}
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Account(String accountNo, String accountName, Integer balance, String accountType, Date lastUpdatedDate) {
		super();
		this.accountNo = accountNo;		
		this.accountName = accountName;
		this.balance = balance;
		this.accountType = accountType;
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public Account() {
		
	}
}
