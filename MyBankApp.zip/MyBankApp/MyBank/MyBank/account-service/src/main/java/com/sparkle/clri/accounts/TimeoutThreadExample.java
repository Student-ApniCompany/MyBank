package com.sparkle.clri.accounts;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.sparkle.clri.accounts.model.Account;

import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.HttpTextFormat;
import io.opentelemetry.trace.Span;
import io.opentelemetry.trace.SpanContext;
import io.opentelemetry.trace.Tracer;


public class TimeoutThreadExample {

	   private ExecutorService executor = Executors.newFixedThreadPool(1);
	   private final RestTemplate restTemplate;
	   public TimeoutThreadExample() {
		    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		    requestFactory.setReadTimeout(0);
		    requestFactory.setConnectTimeout(0);
		    restTemplate = new RestTemplate(requestFactory);
		}


	    public Account getData(String url) throws TimeoutException , InterruptedException, ExecutionException {
	        Future<Account> future = executor.submit(new Task(restTemplate, url, null));
	        Account response = null;
            response = future.get(1000, TimeUnit.MILLISECONDS);
	        return response;
	    }

	    public Account getData(String url, Tracer tracer) throws TimeoutException , InterruptedException, ExecutionException {

	    	Span span = tracer.spanBuilder("getData").startSpan();
			span.setAttribute("request.type", "get account data");


			HttpHeaders header = new HttpHeaders();
			HttpTextFormat<SpanContext> textFormat = tracer.getHttpTextFormat();
			textFormat.inject(span.getContext(), header, new
				      HttpTextFormat.Setter<HttpHeaders>(){

						@Override
						public void put(HttpHeaders template, String key, String value) {
							header.add(key, value);

						}

			});

			try(Scope scope = tracer.withSpan(span)){
	        Future<Account> future = executor.submit(new Task(restTemplate, url, header));
	        Account response = null;
            response = future.get(1000, TimeUnit.MILLISECONDS);
            return response;
			}finally{
				 span.end();
			}
	    }
}
