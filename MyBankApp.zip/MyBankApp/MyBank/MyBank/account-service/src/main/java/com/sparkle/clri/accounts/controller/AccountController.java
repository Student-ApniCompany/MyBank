package com.sparkle.clri.accounts.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.sparkle.clri.accounts.TimeoutThreadExample;
import com.sparkle.clri.accounts.model.Account;
import com.sparkle.clri.accounts.service.AccountServiceImpl;
import com.sparkle.clri.accounts.vo.AccountVO;
import com.sparkle.clri.exception.BusinessException;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.HttpTextFormat;
import io.opentelemetry.trace.Span;
import io.opentelemetry.trace.SpanContext;
import io.opentelemetry.trace.Tracer;


@RestController
public class AccountController {
	@Autowired
	private AccountServiceImpl accountService;

	@Autowired
	MeterRegistry meterRegistry;

	@Autowired
	Tracer tracer;

	@Autowired
	private Environment env;

	String baseUrl="http://localhost:8181";

	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);
	

	@GetMapping("/accounts")
	public List<Account> getaccounts() throws Exception {
		logger.info("get accounts");

		Span span = tracer.spanBuilder("/accounts").startSpan();
		span.addEvent("Accounts controller GET all Accounts API");
		span.setAttribute("request.type", "get all accounts");
		span.setAttribute("http.method", "GET");
		String location=accountService.getGeoLocation();
		if(location!=null)
			span.setAttribute("hosted.geoLocation", location);
		 try(Scope scope = tracer.withSpan(span)){

			 List<Account> accountList = accountService.fetchAllaccounts();
				logger.info("account list"+accountList);
				span.setAttribute("http.status_code", "200");
				return accountList;

		 }catch(Exception e){
             span.addEvent("error");
             span.setAttribute("error", true);
             span.setAttribute("http.status_code", "500");
             return new ArrayList<>();
         }
         finally{
             span.end();
         }


	}

	@GetMapping("/accountbalance/{id:.+}")
	public int getAccountBalance(@PathVariable String id) throws BusinessException {
		logger.info("get account balance");
		Span span = tracer.spanBuilder("/accountbalance/{id}").startSpan();
		span.addEvent(" Accounts controller GET AccountBalance API");
		span.setAttribute("request.type", "get AccountBalance");
		span.setAttribute("http.method", "GET");
		String location=accountService.getGeoLocation();
		if(location!=null)
			span.setAttribute("hosted.geoLocation", location);

		try(Scope scope = tracer.withSpan(span)){
			int balance = accountService.fetchAccountBalance(id);
			logger.info("account balance"+balance);
			span.setAttribute("http.status_code", "200");
			return balance;
		}finally{
			 span.end();
		}
	}


	@GetMapping("/accounts/{id:.+}")
	public Account getAccount(@PathVariable String id) throws BusinessException {
		this.meterRegistry.counter("accountservice.count", "type", "getAccounts").increment(1.0);

		return Timer
		   .builder("getaccount.api")
		   .tags("uri", "/accounts/{id:.+}")
		   .register(this.meterRegistry)
		   .record(() -> {

			   logger.info("get account details");
				Span span = tracer.spanBuilder("/account/{id}").startSpan();
				span.addEvent(" Accounts controller GET Account API");
				span.setAttribute("request.type", "get Account");
				span.setAttribute("http.method", "GET");
				String location=accountService.getGeoLocation();
				if(location!=null)
					span.setAttribute("hosted.geoLocation", location);

		        try(Scope scope = tracer.withSpan(span)){
					Account account = accountService.fetchAccount(id);
					logger.info("account :"+account.getAccountName());
					span.setAttribute("http.status_code", "200");
					return account;
				}finally{
					 span.end();
				}
		   });


	}


	@GetMapping("/accounts/{id:.+}/cheques")
	public Object getAllChequeReqForAccount(@PathVariable String id) throws BusinessException {
		this.meterRegistry.counter("accountservice.count", "type", "getAllChequeReqForAccount").increment(1.0);

		return Timer
		   .builder("getAllChequeReqForAccount.api")
		   .tags("uri", "/accounts/{id:.+}/cheques")
		   .register(this.meterRegistry)
		   .record(() -> {

			   logger.info("get account cheque details");
				Span span = tracer.spanBuilder("/account/{id}/cheques").startSpan();           
				span.addEvent(" Accounts controller GET Account Cheque Details API");
				span.setAttribute("request.type", "get Account Cheques");
				span.setAttribute("http.method", "GET");
				String location=accountService.getGeoLocation();
				if(location!=null)
					span.setAttribute("hosted.geoLocation", location);

		        try(Scope scope = tracer.withSpan(span)){

		        	RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
		    		HttpHeaders header = new HttpHeaders();
		    		HttpTextFormat<SpanContext> textFormat = tracer.getHttpTextFormat();
		    		textFormat.inject(span.getContext(), header, new
		    			      HttpTextFormat.Setter<HttpHeaders>(){

		    					@Override
		    					public void put(HttpHeaders template, String key, String value) {
		    						header.add(key, value);

		    					}

		    		});

		    		String endpoint = env.getProperty("cheque.request.endpoint");
		    		header.set("username", id);


		    		URI uri = URI.create(endpoint + "cheque/account/"+id);
		    		ResponseEntity response = restTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<>(header), Object.class);
		    		Object cheques = response.getBody();
		    		span.end();
		    		return cheques;
				}finally{
					 span.end();
				}
		   });


	}

	@PostMapping("/accounts")
	public ResponseEntity<String> createAccount(@RequestBody AccountVO accountVO) throws BusinessException
	{
		System.out.println("Inside Create Account Controller");
		accountService.createaccount(accountVO);
		HttpHeaders responseHeaders = new HttpHeaders();
		return new ResponseEntity<>(responseHeaders, HttpStatus.OK);
	}


	@PutMapping("/accounts")
	public ResponseEntity<String> updateAccount(@RequestBody AccountVO accountVO) throws BusinessException
	{
		accountService.updateAccount(accountVO);
		HttpHeaders responseHeaders = new HttpHeaders();
		return new ResponseEntity<>(responseHeaders, HttpStatus.OK);
	}





	@RequestMapping("/executeapi")
	public Account executeAPI() throws TimeoutException, InterruptedException, ExecutionException {
		Span span = tracer.spanBuilder("/executeapi").startSpan();
		span.addEvent("Accounts controller executeapi");
		span.setAttribute("request.type", "executeapi");
		span.setAttribute("http.method", "GET");
		String location=accountService.getGeoLocation();
		if(location!=null)
			span.setAttribute("hosted.geoLocation", location);
		 try(Scope scope = tracer.withSpan(span)){
			 this.meterRegistry.counter("account.executeapi", "type", "get").increment(1.0);
			 TimeoutThreadExample example=new TimeoutThreadExample();
			 return example.getData("http://localhost:8090/accounts/smith", tracer);
		 }
		 finally{
			 span.end();
		}
	}

	@RequestMapping("/executeapis/{count:.+}")
	public String increasetraffic(@PathVariable int count) {

		this.meterRegistry.counter("account.executeapis", "type", "executeapis/{count}").increment(count);
		TimeoutThreadExample example=new TimeoutThreadExample();

		for(int i=0;i<count;i++){
			try{
			example.getData("http://localhost:8090/executeapi");
		 } catch (TimeoutException e) {
	            e.printStackTrace();
	     } catch (InterruptedException e) {
	            e.printStackTrace();
	     } catch (ExecutionException e) {
	            e.printStackTrace();
	        }
		}
		return "Successfully initiated "+count+" API calls";
	}



	@RequestMapping("/invokeapi/{count:.+}")
	public Account invokeAPI(@PathVariable int count) throws TimeoutException, InterruptedException {



		Span span = tracer.spanBuilder("/invokeapi/{count}").startSpan();
		span.addEvent(" Accounts controller GET Account API");
		span.setAttribute("request.type", "get Account");
		span.setAttribute("http.method", "GET");

        try(Scope scope = tracer.withSpan(span)){
        	if(count>=10 && count < 50){
    			Random ran = new Random();
    			int x = ran.nextInt(3) + 0;
    			TimeUnit.MILLISECONDS.sleep(x);
    		}
    		else if(count >= 50 && count < 100){
    			Random ran = new Random();
    			int x = ran.nextInt(3) + 5;
    			TimeUnit.MILLISECONDS.sleep(x);
    		}
    		else if(count >= 100 && count < 500 ){
    			Random ran = new Random();
    			int x = ran.nextInt(5) + 10;
    			TimeUnit.MILLISECONDS.sleep(x);
    		}
    		else if(count >= 500 ){
    			Random ran = new Random();
    			int x = ran.nextInt(7) + 20;
    			TimeUnit.MILLISECONDS.sleep(x);
    		}

			Account account = accountService.fetchAccount("smith");
			logger.info("account :"+account.getAccountName());
			span.setAttribute("http.status_code", "200");
			return account;
		}finally{
			 span.end();
		}

	}

	@RequestMapping("/httperror")
	public Account invalidReq() throws TimeoutException, InterruptedException{

		throw new TimeoutException();

	}


	//Override timeouts in request factory
	private ClientHttpRequestFactory  getClientHttpRequestFactory()
	{
	    HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
	                      = new HttpComponentsClientHttpRequestFactory();
	    //Connect timeout
	    clientHttpRequestFactory.setConnectTimeout(200);

	    //Read timeout
	    clientHttpRequestFactory.setReadTimeout(200);
	    return clientHttpRequestFactory;
	}

	public void setBaseUrl(String url) {
		baseUrl = url;
	}
	
}
