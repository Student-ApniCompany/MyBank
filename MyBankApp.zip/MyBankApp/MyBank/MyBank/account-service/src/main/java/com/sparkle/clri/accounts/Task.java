package com.sparkle.clri.accounts;

import java.net.URI;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.sparkle.clri.accounts.model.Account;


class Task implements Callable<Account> {

    private RestTemplate restTemplate;
    private String url;
    private HttpHeaders header;
    public Task(RestTemplate restTemplate, String url, HttpHeaders header) {
        this.restTemplate = restTemplate;
        this.url=url;
        this.header=header;
    }

    @Override
	public Account call() throws TimeoutException , InterruptedException, ExecutionException {
    	Account response ;
    	if(this.header==null)
    		response = restTemplate.getForObject(this.url, Account.class);
    	else{
    		URI uri = URI.create(url);
    		ResponseEntity responseEntity = restTemplate.exchange(uri,  HttpMethod.GET, new HttpEntity<>(header), Account.class);
    		response=(Account)responseEntity.getBody();
    	}
        return response;
    }
}