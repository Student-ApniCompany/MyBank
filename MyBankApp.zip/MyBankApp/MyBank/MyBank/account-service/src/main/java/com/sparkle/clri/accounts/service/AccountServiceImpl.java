package com.sparkle.clri.accounts.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.sparkle.clri.accounts.model.Account;
import com.sparkle.clri.accounts.repository.AccountRepository;
import com.sparkle.clri.accounts.vo.AccountVO;
import com.sparkle.clri.exception.BusinessException;
import com.sparkle.clri.exception.Constants;

import io.opentelemetry.trace.Span;
import io.opentelemetry.trace.Tracer;


@Service
public class AccountServiceImpl {

	@Autowired
	Tracer tracer;

	Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);
	@Autowired
	private AccountRepository accountRepository;


	public List<Account> fetchAllaccounts()
	{
		Span span = tracer.spanBuilder("fetchAllaccounts").startSpan();
		span.setAttribute("peer.service", "mysql");
		span.setAttribute("request.type", "SQL QUERY");
		span.setAttribute("sql.query", "SELECT * FROM account");
		span.end();
		return accountRepository.findAll();
	}

	public int fetchAccountBalance(String id) throws BusinessException
	{
		Span span = tracer.spanBuilder("fetchAccountBalance").startSpan();
		span.setAttribute("peer.service", "mysql");
		span.setAttribute("request.type", "SQL QUERY");
		span.setAttribute("sql.query", "SELECT balance FROM account WHERE account_no="+id);

		Account acc= accountRepository.findByAccountNo(id);
		if (acc == null) {
			span.addEvent("error while fetching the account");
	        span.setAttribute("error", true);
	        logger.error("Account does not exist");
			span.end();
			throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, "");
		}
		span.end();
		return acc.getBalance();

	}

	public Account fetchAccount(String id) throws BusinessException
	{
		Span span = tracer.spanBuilder("fetchAccount").startSpan();
		span.setAttribute("peer.service", "mysql");
		span.setAttribute("request.type", "SQL QUERY");
		span.setAttribute("sql.query", "SELECT * FROM account WHERE account_no="+id);


		Account acc= accountRepository.findByAccountNo(id);
		if (acc == null) {
			span.addEvent("error while fetching the account");
	        span.setAttribute("error", true);
	        span.end();
			logger.error("Account does not exist");
			throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, "");
		}
		span.end();
		return acc;
	}


	public void createaccount(AccountVO accountVO)
	{
		System.out.println("Inside Create Account");
		Account existingAccount = accountRepository.findByAccountNo(accountVO.getAccountNo());
		if (existingAccount != null) {
			logger.error("account already exists");
			throw new BusinessException(Constants.ACCOUNT_EXISTS, "");
		}

		Account account = new Account();
		account.setAccountNo(accountVO.getAccountNo());
		account.setAccountName(accountVO.getAccountName());
		account.setBalance(accountVO.getBalance());
		account.setAccountType(accountVO.getAccountType());
		account.setLastUpdatedDate(new Date());
		accountRepository.save(account);
	}

	public void updateAccount(AccountVO accountVO) throws BusinessException
	{
		Account acc = accountRepository.findByAccountNo(accountVO.getAccountNo());

		if (acc != null) {
			if (StringUtils.isNotEmpty(accountVO.getAccountName())) {
				acc.setAccountName(accountVO.getAccountName());
			}
			if (StringUtils.isNotEmpty(accountVO.getAccountType())) {
				acc.setAccountType(accountVO.getAccountType());
			}
			if (accountVO.getBalance() != null ) {
				acc.setBalance(accountVO.getBalance());
			}
			acc.setLastUpdatedDate(new Date());
			accountRepository.save(acc);
		}


			if (acc == null) {
				throw new BusinessException(Constants.ACCOUNT_NOT_FOUND, "");
			}


	}

	public String getGeoLocation() {
		try{
		File database = new File("/var/lib/geo/GeoLite2-City.mmdb");
		DatabaseReader dbReader = new DatabaseReader.Builder(database).build();
		InetAddress ipAddress;
		if(!System.getProperty("os.name").toLowerCase().contains("win")){
		Process process=Runtime.getRuntime().exec("curl -s http://checkip.amazonaws.com/");
		BufferedReader lineReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String ip=lineReader.readLine();
		ipAddress = InetAddress.getByName(ip);
		}
		else{
		  ipAddress = InetAddress.getLocalHost();
		}

		logger.info("ipAddress:"+ipAddress.getHostAddress());
		CityResponse response = dbReader.city(ipAddress);

		String countryName = response.getCountry().getName();
		String cityName = response.getCity().getName();
		Double latitude = response.getLocation().getLatitude();
		Double longitude = response.getLocation().getLongitude();
		return cityName+":"+countryName+":"+latitude+":"+longitude;
		}catch(IOException | GeoIp2Exception ex ){
			logger.error("Unable to fetch Geo location");
			return null;
	 }


	}

	public static Account getAccountNo() {

		return null;
	}



}
