package com.sparkle.clri.accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = { "com.sparkle.clri.accounts.controller","com.sparkle.clri.accounts.model","com.sparkle.clri.accounts.service","com.sparkle.clri.accounts.repository",
		    "com.sparkle.clri.exception", "com.sparkle.clri.accounts.tracer", "com.sparkle.clri.accounts.configuration" })
@EnableJpaRepositories("com.sparkle.clri.accounts.repository")
@EntityScan("com.sparkle.clri.accounts.model")
public class ClriAccountServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClriAccountServiceApplication.class, args);
	}
}
