package com.sparkle.clri.accounts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sparkle.clri.accounts.model.Account;



@Repository
public interface AccountRepository extends JpaRepository<Account, String> {

	Account findByAccountNo(String accountId);

	@Query("FROM accounts")
	List<Account> findAllaccounts();

	@Query("SELECT a.balance FROM accounts AS a WHERE a.accountNo=:id")
	int findAccountBalance( @Param("id") String id);
}