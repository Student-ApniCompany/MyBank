SET SQL_MODE='ALLOW_INVALID_DATES'; 


CREATE TABLE if not exists accounts (
    account_no VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255),
    balance integer,
	type VARCHAR(255),
	updated_on datetime
	
);

